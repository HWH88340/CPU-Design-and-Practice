#ifndef __CPU_H_
#define __CPU_H_
#define SR_BOOT_EXC_VEC		0x00400000
#define	PG_SIZE_4K	0x00000000
#endif
